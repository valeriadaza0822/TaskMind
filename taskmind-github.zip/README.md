# TaskMind

Proyecto web académico para gestionar tareas, materias, calendario, progreso y alertas.

## Requisitos

- XAMPP o un servidor local con PHP y MySQL.
- Navegador web.

## Instalación local

1. Copiar la carpeta del proyecto dentro de `htdocs` de XAMPP.
2. Iniciar Apache y MySQL desde XAMPP.
3. Crear una base de datos llamada `taskmind`.
4. Importar uno de los archivos SQL de la carpeta `sql`, por ejemplo:
   - `sql/taskmind_completo_con_rutinas.sql`
   - `sql/taskmind_hosting.sql`
5. Revisar la conexión en `config/conexion.php`.
6. Abrir en el navegador:

```text
http://localhost/proyecto/
```

## Estructura

- `index.html`: página principal.
- `auth/`: pantallas de acceso, registro y recuperación.
- `app/`: vistas internas del sistema.
- `acciones/`: lógica de formularios y acciones PHP.
- `config/`: conexión a base de datos.
- `includes/`: funciones compartidas y layout.
- `css/`: estilos.
- `js/`: scripts del frontend.
- `sql/`: scripts de base de datos.

