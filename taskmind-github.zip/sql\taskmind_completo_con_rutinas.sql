SET FOREIGN_KEY_CHECKS = 0;

DROP VIEW IF EXISTS vista_actividades_estudiantes;
DROP PROCEDURE IF EXISTS calcular_indicador;
DROP FUNCTION IF EXISTS calcular_estado_actividad;
DROP TABLE IF EXISTS indicador_academico;
DROP TABLE IF EXISTS historico_usuario;
DROP TABLE IF EXISTS historial_actividad;
DROP TABLE IF EXISTS alerta;
DROP TABLE IF EXISTS actividad;
DROP TABLE IF EXISTS sede;
DROP TABLE IF EXISTS materias;
DROP TABLE IF EXISTS usuario;
DROP TABLE IF EXISTS periodo;
DROP TABLE IF EXISTS institucion;
DROP TABLE IF EXISTS tipo_periodo;
DROP TABLE IF EXISTS prioridad;
DROP TABLE IF EXISTS nivel_riesgo;
DROP TABLE IF EXISTS estado_general;
DROP TABLE IF EXISTS estado_alerta;
DROP TABLE IF EXISTS estado;
DROP TABLE IF EXISTS contacto;

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE contacto (
    id_contacto INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(100) DEFAULT NULL,
    correo VARCHAR(100) DEFAULT NULL,
    tipo_mensaje VARCHAR(50) DEFAULT NULL,
    mensaje TEXT,
    fecha_envio DATE DEFAULT NULL,
    PRIMARY KEY (id_contacto)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE estado (
    id_estado INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL,
    PRIMARY KEY (id_estado)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE estado_alerta (
    id_estado_alerta INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL,
    PRIMARY KEY (id_estado_alerta)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE estado_general (
    id_estado INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(50) DEFAULT NULL,
    PRIMARY KEY (id_estado)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE nivel_riesgo (
    id_nivel_riesgo INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL,
    PRIMARY KEY (id_nivel_riesgo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE prioridad (
    id_prioridad INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL,
    PRIMARY KEY (id_prioridad)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE tipo_periodo (
    id_tipo_periodo INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL,
    PRIMARY KEY (id_tipo_periodo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE institucion (
    id_institucion INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    id_tipo_periodo INT DEFAULT NULL,
    PRIMARY KEY (id_institucion),
    KEY id_tipo_periodo (id_tipo_periodo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE periodo (
    id_periodo INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL,
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE DEFAULT NULL,
    id_institucion INT DEFAULT NULL,
    PRIMARY KEY (id_periodo),
    KEY id_institucion (id_institucion)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE usuario (
    id_usuario INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    correo VARCHAR(100) NOT NULL,
    contrasena VARCHAR(255) NOT NULL,
    fecha_registro DATE DEFAULT NULL,
    id_institucion INT DEFAULT NULL,
    id_estado INT DEFAULT NULL,
    telefono VARCHAR(30) DEFAULT NULL,
    documento VARCHAR(40) DEFAULT NULL,
    institucion_texto VARCHAR(120) DEFAULT NULL,
    programa_academico VARCHAR(120) DEFAULT NULL,
    semestre_actual INT DEFAULT NULL,
    jornada VARCHAR(50) DEFAULT NULL,
    PRIMARY KEY (id_usuario),
    UNIQUE KEY correo_unico (correo),
    KEY fecha_registro (fecha_registro),
    KEY id_institucion (id_institucion),
    KEY id_estado (id_estado)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE materias (
    id_materias INT NOT NULL AUTO_INCREMENT,
    nombre_materia VARCHAR(100) NOT NULL,
    descripcion TEXT,
    semestre INT NOT NULL DEFAULT 1,
    id_usuario INT DEFAULT NULL,
    PRIMARY KEY (id_materias),
    KEY id_usuario (id_usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE sede (
    id_sede INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    direccion VARCHAR(150) DEFAULT NULL,
    id_institucion INT NOT NULL,
    PRIMARY KEY (id_sede),
    KEY id_institucion (id_institucion)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE actividad (
    id_actividad INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    fecha_entrega DATE NOT NULL,
    tipo_periodo_texto VARCHAR(30) DEFAULT NULL,
    periodo_texto VARCHAR(50) DEFAULT NULL,
    fecha_completada DATETIME DEFAULT NULL,
    id_materia INT DEFAULT NULL,
    id_estado INT DEFAULT NULL,
    id_prioridad INT DEFAULT NULL,
    id_periodo INT NOT NULL DEFAULT 1,
    PRIMARY KEY (id_actividad),
    KEY id_materia (id_materia),
    KEY id_estado (id_estado),
    KEY id_prioridad (id_prioridad),
    KEY id_periodo (id_periodo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE alerta (
    id_alertas INT NOT NULL AUTO_INCREMENT,
    mensaje TEXT NOT NULL,
    fecha_alerta DATETIME NOT NULL,
    id_estado_alerta INT DEFAULT NULL,
    id_actividad INT DEFAULT NULL,
    PRIMARY KEY (id_alertas),
    KEY id_estado_alerta (id_estado_alerta),
    KEY id_actividad (id_actividad)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE historial_actividad (
    id_historial INT NOT NULL AUTO_INCREMENT,
    id_actividad INT DEFAULT NULL,
    accion VARCHAR(50) DEFAULT NULL,
    fecha DATETIME DEFAULT NULL,
    PRIMARY KEY (id_historial),
    KEY id_actividad (id_actividad)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE historico_usuario (
    id_historico INT NOT NULL AUTO_INCREMENT,
    id_usuario INT DEFAULT NULL,
    tabla_afectada VARCHAR(50) DEFAULT NULL,
    accion VARCHAR(20) DEFAULT NULL,
    descripcion TEXT,
    fecha DATETIME DEFAULT NULL,
    PRIMARY KEY (id_historico),
    KEY id_usuario (id_usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE indicador_academico (
    id_indicador_academico INT NOT NULL AUTO_INCREMENT,
    porcentaje_cumplimiento DECIMAL(5,2) NOT NULL,
    fecha_calculo DATE NOT NULL,
    id_usuario INT DEFAULT NULL,
    id_periodo INT DEFAULT NULL,
    id_nivel INT DEFAULT NULL,
    PRIMARY KEY (id_indicador_academico),
    KEY id_usuario (id_usuario),
    KEY id_periodo (id_periodo),
    KEY id_nivel (id_nivel)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO estado (id_estado, nombre) VALUES
(1, 'Pendiente'),
(2, 'Completada'),
(3, 'Vencida');

INSERT INTO estado_alerta (id_estado_alerta, nombre) VALUES
(1, 'Sin leer'),
(2, 'Leída');

INSERT INTO estado_general (id_estado, nombre) VALUES
(1, 'Activo'),
(2, 'Inactivo');

INSERT INTO prioridad (id_prioridad, nombre) VALUES
(1, 'Alta'),
(2, 'Media'),
(3, 'Baja');

INSERT INTO nivel_riesgo (id_nivel_riesgo, nombre) VALUES
(1, 'Bajo'),
(2, 'Medio'),
(3, 'Alto');

INSERT INTO tipo_periodo (id_tipo_periodo, nombre) VALUES
(1, 'Semestral'),
(2, 'Trimestral'),
(3, 'Bimestral'),
(4, 'Anual');

INSERT INTO institucion (id_institucion, nombre, id_tipo_periodo) VALUES
(1, 'Institución principal', 1);

INSERT INTO periodo (id_periodo, nombre, fecha_inicio, fecha_fin, id_institucion) VALUES
(1, '2026-1', '2026-01-01', '2026-06-30', 1);

DELIMITER //

CREATE FUNCTION calcular_estado_actividad(fechaEntrega DATE, estadoId INT)
RETURNS VARCHAR(20)
DETERMINISTIC
BEGIN
    DECLARE resultado VARCHAR(20);

    IF estadoId = 2 THEN
        SET resultado = 'Completada';
    ELSEIF fechaEntrega < CURDATE() THEN
        SET resultado = 'Vencida';
    ELSE
        SET resultado = 'Pendiente';
    END IF;

    RETURN resultado;
END//

CREATE PROCEDURE calcular_indicador(IN idUser INT, IN idPeriodo INT)
BEGIN
    DECLARE total INT DEFAULT 0;
    DECLARE completadas INT DEFAULT 0;
    DECLARE porcentaje DECIMAL(5,2) DEFAULT 0;

    SELECT COUNT(*) INTO total
    FROM actividad a
    INNER JOIN materias m ON a.id_materia = m.id_materias
    WHERE m.id_usuario = idUser
    AND a.id_periodo = idPeriodo;

    SELECT COUNT(*) INTO completadas
    FROM actividad a
    INNER JOIN materias m ON a.id_materia = m.id_materias
    WHERE m.id_usuario = idUser
    AND a.id_periodo = idPeriodo
    AND a.id_estado = 2;

    IF total > 0 THEN
        SET porcentaje = (completadas / total) * 100;
    END IF;

    INSERT INTO indicador_academico
    (id_usuario, porcentaje_cumplimiento, fecha_calculo, id_periodo)
    VALUES (idUser, porcentaje, CURDATE(), idPeriodo);
END//

DELIMITER ;

CREATE VIEW vista_actividades_estudiantes AS
SELECT
    u.id_usuario AS id_usuario,
    u.nombre AS estudiante,
    a.id_actividad AS id_actividad,
    a.nombre AS actividad,
    a.fecha_entrega AS fecha_entrega,
    calcular_estado_actividad(a.fecha_entrega, a.id_estado) AS estado,
    p.nombre AS periodo
FROM actividad a
INNER JOIN materias m ON a.id_materia = m.id_materias
INNER JOIN usuario u ON m.id_usuario = u.id_usuario
INNER JOIN periodo p ON a.id_periodo = p.id_periodo;
